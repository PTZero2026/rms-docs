---
title: "Kỳ nhận đề xuất — Test plan"
spec: "./spec.md"
owner: "PO/BA"
status: Review
updated: 2026-11-25
---

# Kỳ nhận đề xuất — Kế hoạch kiểm thử

> Mỗi test case bám vào một AC trong [`spec.md`](./spec.md). Không có AC tương ứng = thiếu yêu cầu, báo lại BA/PO.

## 1. Phạm vi kiểm thử

- **Mặt test:** BO (tạo/sửa/vận hành kỳ), FE (danh sách & chi tiết kỳ cho nhà khoa học), API (quyền,
  ràng buộc trạng thái, validate), job đóng kỳ tự động.
- **Môi trường:** môi trường staging với SSO giả lập; múi giờ Asia/Ho_Chi_Minh.
- **Dữ liệu mẫu:**
  - Tài khoản: 1 chuyên viên QL KHCN (có `PROPOSAL_CALL.MANAGE`), 1 nhà khoa học, 1 thành viên hội đồng.
  - Danh mục B01 `ACTIVE`: ≥2 `ResearchField`, 1 biểu mẫu thuyết minh, 1 bộ tiêu chí xét duyệt.
  - Kỳ mẫu: `KG-2026-01` (`OPEN`, trong hạn, chưa có đề xuất), `KG-2026-02` (`OPEN`, đã có 1 đề tài `SUBMITTED`),
    `KG-2026-03` (`OPEN`, `endDate` = hôm qua), `KG-2026-09` (`DRAFT`, cấu hình đủ).

## 2. Test cases

| ID    | Liên kết AC | Tiền điều kiện | Bước thực hiện | Kết quả mong đợi | Loại |
|-------|-------------|----------------|----------------|------------------|------|
| TC-01 | AC-01 | Đăng nhập chuyên viên | BO-02: nhập `code=KG-2026-10`, `name`, `startDate≤endDate` hợp lệ → Lưu | Kỳ lưu ở `DRAFT`, hiện trong BO-01 | Happy |
| TC-02 | AC-02 | Kỳ `KG-2026-09` (`DRAFT`) cấu hình đủ, danh mục `ACTIVE` | BO-03: bấm "Mở kỳ" | Kỳ chuyển `OPEN`, ghi nhật ký; xuất hiện trên FE-01 | Happy |
| TC-03 | AC-02 / BR-03 | Kỳ `DRAFT` thiếu `reviewCriteriaSetId` | BO-03: bấm "Mở kỳ" | Bị chặn, thông báo thiếu cấu hình bắt buộc, kỳ vẫn `DRAFT` | Biên/Lỗi |
| TC-04 | AC-02 / BR-04 | Kỳ nháp đủ cấu hình. Lần lượt thử từng tham chiếu bị đặt INACTIVE sau khi lưu nháp (lĩnh vực, biểu mẫu, bộ tiêu chí) | Bấm Mở kỳ, ghi nhận trạng thái, thay mục bằng bản còn hiệu lực và thử mở lại | Lần đầu vẫn DRAFT, báo đúng mục cần thay. Lần sau cùng kỳ chuyển OPEN và hiển thị cho nhà khoa học | Biên/Lỗi |
| TC-05 | AC-03 | Nhà khoa học đăng nhập; kỳ `KG-2026-01` `OPEN` trong hạn | FE-01 → FE-02 → bấm "Nộp đề xuất" | Điều hướng sang F01 với `proposalCallId` đúng và biểu mẫu nạp sẵn | Happy |
| TC-06 | AC-04 | Kỳ `KG-2026-03` `OPEN`, `endDate` = hôm qua | Chạy job đóng kỳ (hoặc đóng thủ công) | Kỳ chuyển `CLOSED`, biến mất khỏi FE-01, ghi nhật ký | Biên |
| TC-07 | AC-04 / BR-05 | Kỳ vừa `CLOSED` ở TC-06 | Gọi API nộp đề xuất (F01) vào kỳ này | Bị từ chối, không tạo đề tài mới | Biên/Lỗi |
| TC-08 | AC-05 / BR-01 | Đăng nhập chuyên viên | BO-02: nhập `endDate` < `startDate` → Lưu | Bị từ chối, lỗi inline "Đến ngày phải ≥ Từ ngày", không lưu | Biên/Lỗi |
| TC-09 | AC-05 / BR-02 | Đã tồn tại kỳ `code=KG-2026-01` | BO-02: tạo kỳ mới `code=KG-2026-01` → Lưu | Bị từ chối, lỗi "Mã kỳ đã tồn tại", không lưu | Biên/Lỗi |
| TC-10 | AC-06 / BR-06 | Kỳ `KG-2026-02` `OPEN` đã có 1 đề tài `SUBMITTED` | BO-02 (sửa): thử đổi `researchFieldIds`/`proposalTemplateId`/`startDate` | Các trường bị vô hiệu/chặn, không lưu được thay đổi đó | Biên/Lỗi |
| TC-11 | AC-06 / BR-06 | Kỳ `KG-2026-02` như trên | BO-03: gia hạn `endDate` về tương lai → Lưu | Cho phép, chỉ `endDate` đổi, ghi nhật ký | Happy |
| TC-12 | AC-07 / BR-07 | Kỳ `KG-2026-02` đã có đề tài `SUBMITTED` | BO-03: bấm "Hủy kỳ" | Bị chặn, thông báo phải "Đóng" thay vì "Hủy"; trạng thái không đổi | Biên/Lỗi |
| TC-13 | AC-07 / BR-07 | Kỳ `KG-2026-01` `OPEN` chưa có đề xuất | BO-03: bấm "Hủy kỳ", nhập `reason` | Kỳ chuyển `CANCELLED`, ghi nhật ký kèm `reason`, ẩn khỏi FE | Happy |
| TC-14 | AC-08 | Đăng nhập nhà khoa học (không có `PROPOSAL_CALL.MANAGE`) | Gọi API tạo/mở/đóng/hủy kỳ | Trả 403, dữ liệu không đổi | Negative/Quyền |
| TC-15 | AC-08 | Đăng nhập thành viên hội đồng | Mở URL màn hình BO-02/BO-03 trực tiếp | Không vào được/ẩn hành động; API từ chối 403 | Negative/Quyền |
| TC-16 | AC-02 / BR-08 | Không có kỳ nào `OPEN` hợp lệ | FE-01: tải danh sách | Hiển thị trạng thái rỗng "Chưa có kỳ nhận đề xuất nào đang mở" | Biên |

## 3. Trường hợp biên & negative

- **Dữ liệu rỗng:** FE-01 không có kỳ `OPEN` (TC-16); BO-01 chưa có kỳ nào.
- **Quá hạn / đua dữ liệu:** kỳ hết hạn đúng lúc nhà khoa học bấm "Nộp đề xuất" → nút vô hiệu phía
  FE và backend từ chối (TC-06/TC-07).
- **Trùng:** `code` kỳ trùng (TC-09).
- **Khoảng thời gian sai:** `endDate < startDate` (TC-08); `endDate` quá khứ khi mở.
- **Tham chiếu danh mục mất hiệu lực:** `ResearchField`/biểu mẫu/bộ tiêu chí bị `INACTIVE` sau khi cấu hình (TC-04).
- **Khóa cấu hình:** sửa trường bị khóa khi kỳ đã có đề xuất (TC-10); hủy kỳ đã có đề xuất (TC-12).
- **Sai quyền:** truy cập API/màn hình quản trị không đủ quyền (TC-14, TC-15).
- **Mở lại kỳ đã đóng:** `CLOSED → OPEN` chỉ khi gia hạn `endDate` hợp lệ (mở rộng từ TC-11).

## 4. Checklist hồi quy

- **F01 — Đề xuất đề tài:** nộp đề xuất chỉ thành công khi kỳ `OPEN` trong hạn; biểu mẫu thuyết minh
  nạp đúng theo kỳ; kỳ `CLOSED`/`CANCELLED` từ chối nộp.
- **F03 — Xét duyệt:** bộ tiêu chí dùng để chấm khớp `reviewCriteriaSetId` của kỳ (không lệch sau gia hạn).
- **B01 — Danh mục:** đặt `INACTIVE` lĩnh vực/biểu mẫu/bộ tiêu chí không phá vỡ kỳ đã mở (ràng buộc tham chiếu).
- **B03 — Phân quyền:** thay đổi quyền `PROPOSAL_CALL.MANAGE` phản ánh đúng ở ẩn/hiện hành động BO.
- **Audit:** mọi chuyển trạng thái kỳ (mở/đóng/hủy/gia hạn) đều sinh bản ghi `AuditLog`.
- **Job đóng kỳ:** chạy đúng theo cuối ngày `endDate` múi giờ Asia/Ho_Chi_Minh, không lệch ngày.

## Tra kỳ trên điện thoại

| Ca | AC nguồn | Điều kiện | Thao tác | Kết quả |
|---|---|---|---|---|
| TC-17 | AC-09 | Có kỳ đang nhận, kỳ đã đóng và bản nháp | Mở F02 trên điện thoại | Nhóm đang nhận chỉ hiển thị kỳ đang trong cửa sổ nhận. |
| TC-18 | AC-09 | Kỳ KG-2027-01 kết thúc 30/11/2026 | Tìm kg-2027-01 rồi mở thẻ | Thẻ hiện hạn 30/11/2026. Chi tiết hiện mã kỳ, biểu mẫu và hành động F01 phù hợp quyền. |
| TC-19 | AC-09 | Từ khóa không khớp | Tìm rồi xóa từ khóa | Có thông điệp rỗng và danh sách được phục hồi. |
| TC-20 | AC-09 | Một chuyên viên được quản lý kỳ nháp, một chủ nhiệm chỉ tra kỳ mở | Mỗi người chọn Tất cả | Kỳ nháp chỉ xuất hiện cho chuyên viên có quyền. Kỳ OPEN tương lai hoặc hết hạn bị loại khỏi Đang nhận. |

**Đối chứng AC-04 / TC-06.** Dùng hai mốc UTC cách nhau một mili giây qua nửa đêm Việt Nam, hai worker đồng thời và một giao dịch gia hạn giữ khóa. Đối chiếu số lần tăng phiên bản, trạng thái, audit hệ thống, hoàn tác, kỳ nháp, kỳ đã hủy và trường khác. Trên Chrome, mở kỳ từ danh sách **Tất cả** của chuyên viên, chạy worker rồi gửi lệnh từ phiên bản cũ. Mở lại đúng mã kỳ, kiểm lý do và hạn mới khi gia hạn. Kiểm nút nộp tự khóa ngay trên tab chủ nhiệm, HTTP 409 khi bản đang xem đã cũ và mã đề tài sau khi nộp lại bản nháp còn trong hạn mới. [Ca PostgreSQL](../../../apps/backend/test/db/call-expiry.test.mjs) · [Kịch bản Chrome](../../../e2e/call/open-call/expiry.spec.ts)
