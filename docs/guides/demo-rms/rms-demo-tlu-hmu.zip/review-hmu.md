# Phiếu review · Đại học Y Hà Nội

Người review ____________________    Ngày ____________________

| Ca | Mục tiêu | Kết quả thực tế | Đạt / Cần sửa / Chưa chạy | Bằng chứng và mã vấn đề |
|---|---|---|---|---|
| HMU-01 | Tôi muốn biết việc nào cần xử lý đầu tiên. | | Chưa chạy | |
| HMU-02 | Tôi cần biết kỳ nào còn nhận đề xuất. | | Chưa chạy | |
| HMU-03 | Tôi cần phát hiện tiêu chí cũ trước khi mở kỳ. | | Chưa chạy | |
| HMU-04 | Tôi muốn nộp thuyết minh và giữ được mã theo dõi. | | Chưa chạy | |
| HMU-05 | Tôi muốn biết mình phải bổ sung gì và nộp lại đúng hồ sơ. | | Chưa chạy | |
| HMU-06 | Tôi cần giải thích vì sao hồ sơ từng về nháp. | | Chưa chạy | |
| HMU-07 | Tôi muốn gửi phiếu khoa học độc lập. | | Chưa chạy | |
| HMU-08 | Tôi cần tách quyết định khoa học khỏi thẩm định đạo đức. | | Chưa chạy | |
| HMU-09 | Tôi cần biết hồ sơ nào mình phải tránh chấm. | | Chưa chạy | |
| HMU-10 | Tôi muốn bảo vệ số liệu báo cáo khi hồ sơ nguồn thay đổi. | | Chưa chạy | |
| HMU-11 | Tôi muốn giao nhiệm vụ đã duyệt và lập kỳ theo dõi. | | Chưa chạy | |
| HMU-12 | Tôi cần nộp báo cáo quá hạn và nhận phản hồi. | | Chưa chạy | |
| HMU-13 | Tôi muốn đọc nhắc việc và đi thẳng tới kỳ nhận hồ sơ. | | Chưa chạy | |
| HMU-14 | Tôi cần gửi lại một email nhắc hạn bị lỗi. | | Chưa chạy | |
| HMU-15 | Tôi muốn biết một khoản chi mới có làm vượt kinh phí thực hiện. | | Chưa chạy | |
| HMU-16 | Tôi cần quyết toán sau khi rà soát chứng từ thủ công. | | Chưa chạy | |
| HMU-17 | Tôi muốn sản phẩm chỉ được tính sau khi duyệt minh chứng. | | Chưa chạy | |
| HMU-18 | Tôi cần kê khai phần mềm độc lập và theo dõi hồ sơ bị trả. | | Chưa chạy | |
| HMU-19 | Tôi cần mở hội đồng nghiệm thu đúng hồ sơ. | | Chưa chạy | |
| HMU-20 | Tôi muốn chốt điểm của mình và xem kết luận có đúng trọng số. | | Chưa chạy | |
| HMU-21 | Tôi muốn xuất lý lịch cho hội đồng và kiểm tra từng nguồn. | | Chưa chạy | |
| HMU-22 | Tôi cần xin quyền tác giả để nộp đề tài. | | Chưa chạy | |
| HMU-23 | Tôi cần kiểm quyền khi khóa và mở lại tài khoản. | | Chưa chạy | |
| HMU-24 | Tôi muốn kiểm tra phạm vi cấu hình hoạt động mở rộng. | | Chưa chạy | |
| HMU-25 | Tôi cần ghi nhận nhiệm vụ cấp Bộ và tỷ lệ tham gia. | | Chưa chạy | |
| HMU-26 | Tôi cần xác nhận hướng dẫn đúng nhóm sinh viên. | | Chưa chạy | |
| HMU-27 | Tôi cần nộp kết quả để giảng viên hướng dẫn và chuyên viên xác nhận. | | Chưa chạy | |
| HMU-28 | Tôi muốn thử hồ sơ còn thiếu đối tác trước khi chuyển giao. | | Chưa chạy | |
| HMU-29 | Tôi cần giải thích số giờ từ một hợp đồng bàn giao. | | Chưa chạy | |
| HMU-30 | Tôi cần kiểm minh chứng và định mức theo ngày ghi nhận. | | Chưa chạy | |
| HMU-31 | Tôi muốn rà số giờ gốc và đối chiếu một bút toán điều chỉnh. | | Chưa chạy | |
| HMU-32 | Tôi cần thử phiên bản quy trình mới trên hồ sơ lập sau. | | Chưa chạy | |
| HMU-33 | Tôi muốn kiểm tra nguồn trước khi dùng trợ lý rà phương pháp. | | Chưa chạy | |
| HMU-34 | Tôi cần biết thẻ đọc được phép trích phần nào. | | Chưa chạy | |
| HMU-35 | Tôi cần đảm bảo báo cáo và tìm kiếm chỉ hiện hồ sơ trong khoa được giao. | | Chưa chạy | |
| HMU-36 | Tôi muốn mở đúng một đợt xét duyệt cho hồ sơ đã chốt. | | Chưa chạy | |
| HMU-37 | Tôi cần cấp kinh phí sau khi có quyết định giao. | | Chưa chạy | |
| HMU-38 | Tôi muốn tạm dừng rồi cho nhóm tiếp tục thực hiện. | | Chưa chạy | |
| HMU-39 | Tôi cần kiểm việc thu hồi nguồn AI ngay trong buổi review. | | Chưa chạy | |
| HMU-40 | Tôi cần xử lý hỗ trợ cho hoạt động phục vụ cộng đồng. | | Chưa chạy | |
| HMU-41 | Tôi cần thu hồi ghi nhận khi biên bản bàn giao phải đính chính. | | Chưa chạy | |
| HMU-42 | Tôi muốn tìm kỳ đang nhận đề xuất bằng điện thoại. | | Chưa chạy | |
| HMU-43 | Tôi muốn kiểm tra liên kết thông báo khi đổi người nhận. | | Chưa chạy | |
