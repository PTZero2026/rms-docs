# Phiếu review · Đại học Thủy lợi

Người review ____________________    Ngày ____________________

| Ca | Mục tiêu | Kết quả thực tế | Đạt / Cần sửa / Chưa chạy | Bằng chứng và mã vấn đề |
|---|---|---|---|---|
| TLU-01 | Tôi muốn biết việc nào cần xử lý đầu tiên. | | Chưa chạy | |
| TLU-02 | Tôi cần biết kỳ nào còn nhận đề xuất. | | Chưa chạy | |
| TLU-03 | Tôi cần phát hiện tiêu chí cũ trước khi mở kỳ. | | Chưa chạy | |
| TLU-04 | Tôi muốn nộp thuyết minh và giữ được mã theo dõi. | | Chưa chạy | |
| TLU-05 | Tôi muốn biết mình phải bổ sung gì và nộp lại đúng hồ sơ. | | Chưa chạy | |
| TLU-06 | Tôi cần giải thích vì sao hồ sơ từng về nháp. | | Chưa chạy | |
| TLU-07 | Tôi muốn gửi phiếu khoa học độc lập. | | Chưa chạy | |
| TLU-08 | Tôi cần tách quyết định khoa học khỏi thẩm định đạo đức. | | Chưa chạy | |
| TLU-09 | Tôi cần biết hồ sơ nào mình phải tránh chấm. | | Chưa chạy | |
| TLU-10 | Tôi muốn bảo vệ số liệu báo cáo khi hồ sơ nguồn thay đổi. | | Chưa chạy | |
| TLU-11 | Tôi muốn giao nhiệm vụ đã duyệt và lập kỳ theo dõi. | | Chưa chạy | |
| TLU-12 | Tôi cần nộp báo cáo quá hạn và nhận phản hồi. | | Chưa chạy | |
| TLU-13 | Tôi muốn đọc nhắc việc và đi thẳng tới kỳ nhận hồ sơ. | | Chưa chạy | |
| TLU-14 | Tôi cần gửi lại một email nhắc hạn bị lỗi. | | Chưa chạy | |
| TLU-15 | Tôi muốn biết một khoản chi mới có làm vượt kinh phí thực hiện. | | Chưa chạy | |
| TLU-16 | Tôi cần quyết toán sau khi đối soát hai giao dịch. | | Chưa chạy | |
| TLU-17 | Tôi muốn sản phẩm chỉ được tính sau khi duyệt minh chứng. | | Chưa chạy | |
| TLU-18 | Tôi cần kê khai phần mềm độc lập và theo dõi hồ sơ bị trả. | | Chưa chạy | |
| TLU-19 | Tôi cần mở hội đồng nghiệm thu đúng hồ sơ. | | Chưa chạy | |
| TLU-20 | Tôi muốn chốt điểm của mình và xem kết luận có đúng trọng số. | | Chưa chạy | |
| TLU-21 | Tôi muốn xuất lý lịch cho hội đồng và kiểm tra từng nguồn. | | Chưa chạy | |
| TLU-22 | Tôi cần xin quyền tác giả để nộp đề tài. | | Chưa chạy | |
| TLU-23 | Tôi cần kiểm quyền khi khóa và mở lại tài khoản. | | Chưa chạy | |
| TLU-24 | Tôi muốn kiểm tra phạm vi cấu hình hoạt động mở rộng. | | Chưa chạy | |
| TLU-25 | Tôi cần ghi nhận nhiệm vụ cấp Bộ và tỷ lệ tham gia. | | Chưa chạy | |
| TLU-26 | Tôi cần xác nhận hướng dẫn đúng nhóm sinh viên. | | Chưa chạy | |
| TLU-27 | Tôi cần nộp kết quả để giảng viên hướng dẫn và chuyên viên xác nhận. | | Chưa chạy | |
| TLU-28 | Tôi muốn thử hồ sơ còn thiếu đối tác trước khi chuyển giao. | | Chưa chạy | |
| TLU-29 | Tôi cần giải thích số giờ từ một hợp đồng bàn giao. | | Chưa chạy | |
| TLU-30 | Tôi cần kiểm minh chứng và định mức theo ngày ghi nhận. | | Chưa chạy | |
| TLU-31 | Tôi muốn rà số giờ gốc và đối chiếu một bút toán điều chỉnh. | | Chưa chạy | |
| TLU-32 | Tôi cần thử phiên bản quy trình mới trên hồ sơ lập sau. | | Chưa chạy | |
| TLU-33 | Tôi muốn kiểm tra nguồn trước khi dùng trợ lý rà phương pháp. | | Chưa chạy | |
| TLU-34 | Tôi cần biết thẻ đọc được phép trích phần nào. | | Chưa chạy | |
| TLU-35 | Tôi cần đảm bảo báo cáo và tìm kiếm chỉ hiện hồ sơ trong khoa được giao. | | Chưa chạy | |
| TLU-36 | Tôi muốn mở đúng một đợt xét duyệt cho hồ sơ đã chốt. | | Chưa chạy | |
| TLU-37 | Tôi cần cấp kinh phí sau khi có quyết định giao. | | Chưa chạy | |
| TLU-38 | Tôi muốn tạm dừng rồi cho nhóm tiếp tục thực hiện. | | Chưa chạy | |
| TLU-39 | Tôi cần kiểm việc thu hồi nguồn AI ngay trong buổi review. | | Chưa chạy | |
| TLU-40 | Tôi cần xử lý hỗ trợ cho hoạt động phục vụ cộng đồng. | | Chưa chạy | |
| TLU-41 | Tôi cần thu hồi ghi nhận khi biên bản bàn giao phải đính chính. | | Chưa chạy | |
| TLU-42 | Tôi muốn tìm kỳ đang nhận đề xuất bằng điện thoại. | | Chưa chạy | |
| TLU-43 | Tôi muốn kiểm tra liên kết thông báo khi đổi người nhận. | | Chưa chạy | |
